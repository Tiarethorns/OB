const tiare = [
  (nombre = "Tiare Espinoza"),
  (edad = 34),
  (isDev = true),
  (cumpleaños = new Date("june 20 1988")),
  (libro = {
    autor: "hermann hesse",
    titulo: "Damian",
    fecha: new Date("april 5 2020"),
    url: "http://biblio3.url.edu.gt/Libros/2011/Demian.pdf",
  }),
];
console.log(tiare);
